package Movie;
import java.util.Scanner;
public class MovieDriver2 {
	public static void main(String[] args) {
		
		Scanner keyboard = new Scanner(System.in);
		Movie movie = new Movie();
		String again;
		
		do {
		System.out.println("Enter the name of a movie: ");
		String title = keyboard.nextLine();
		
		movie.setTitle(title);
		
		System.out.println("Enter the rating of the movie: ");
		String rating = keyboard.nextLine();
		
		movie.setRating(rating);
		
		System.out.println("Enter the number of tickets sold for this movie: ");
		int ticketsSold = keyboard.nextInt();
		
		keyboard.nextLine();
		
		movie.setSoldTickets(ticketsSold);
		
		System.out.println(movie.toString());
		
		System.out.println("Do you want to enter another? (y or n) ");
		again = keyboard.nextLine();
		
		} while (!again.equals("n"));
		
		System.out.println("Goodbye");
		
		keyboard.close();
	}
}
